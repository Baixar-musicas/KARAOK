
function handlerFunkcija() {
    var input, filter, ul, li, a, i;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName('li');
    // Iteracija kroz listu, i sakrivanje onih koji ne odgovaraju
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}






function opennomecidade10(nomecidade,elmnt,color) {

  var seila, conteudo12, aba10;
  conteudo12 = document.getElementsByClassName("conteudo12");
  for (seila = 0; seila < conteudo12.length; seila++) {
    conteudo12[seila].style.display = "none";
  }

  aba10 = document.getElementsByClassName("aba10");
  for (seila = 0; seila < aba10.length; seila++) {
    aba10[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("decimoprimeiro").click();






function opennomecidade09(nomecidade,elmnt,color) {

  var seila, conteudo11, aba09;
  conteudo11 = document.getElementsByClassName("conteudo11");
  for (seila = 0; seila < conteudo11.length; seila++) {
    conteudo11[seila].style.display = "none";
  }

  aba09 = document.getElementsByClassName("aba09");
  for (seila = 0; seila < aba09.length; seila++) {
    aba09[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("decimo").click();






function opennomecidade08(nomecidade,elmnt,color) {

  var seila, conteudo10, aba08;
  conteudo10 = document.getElementsByClassName("conteudo10");
  for (seila = 0; seila < conteudo10.length; seila++) {
    conteudo10[seila].style.display = "none";
  }

  aba08 = document.getElementsByClassName("aba08");
  for (seila = 0; seila < aba08.length; seila++) {
    aba08[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("nono").click();






function opennomecidade07(nomecidade,elmnt,color) {

  var seila, conteudo09, aba07;
  conteudo09 = document.getElementsByClassName("conteudo09");
  for (seila = 0; seila < conteudo09.length; seila++) {
    conteudo09[seila].style.display = "none";
  }

  aba07 = document.getElementsByClassName("aba07");
  for (seila = 0; seila < aba07.length; seila++) {
    aba07[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("oitavo").click();





function opennomecidade06(nomecidade,elmnt,color) {

  var seila, conteudo08, aba06;
  conteudo08 = document.getElementsByClassName("conteudo08");
  for (seila = 0; seila < conteudo08.length; seila++) {
    conteudo08[seila].style.display = "none";
  }

  aba06 = document.getElementsByClassName("aba06");
  for (seila = 0; seila < aba06.length; seila++) {
    aba06[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("setimo").click();








function opennomecidade05(nomecidade,elmnt,color) {

  var seila, conteudo07, aba05;
  conteudo07 = document.getElementsByClassName("conteudo07");
  for (seila = 0; seila < conteudo07.length; seila++) {
    conteudo07[seila].style.display = "none";
  }

  aba05 = document.getElementsByClassName("aba05");
  for (seila = 0; seila < aba05.length; seila++) {
    aba05[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("sexto").click();










function opennomecidade04(nomecidade,elmnt,color) {

  var seila, conteudo06, aba04;
  conteudo06 = document.getElementsByClassName("conteudo06");
  for (seila = 0; seila < conteudo06.length; seila++) {
    conteudo06[seila].style.display = "none";
  }

  aba04 = document.getElementsByClassName("aba04");
  for (seila = 0; seila < aba04.length; seila++) {
    aba04[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("quinto").click();








function opennomecidade03(nomecidade,elmnt,color) {

  var seila, conteudo05, aba03;
  conteudo05 = document.getElementsByClassName("conteudo05");
  for (seila = 0; seila < conteudo05.length; seila++) {
    conteudo05[seila].style.display = "none";
  }

  aba03 = document.getElementsByClassName("aba03");
  for (seila = 0; seila < aba03.length; seila++) {
    aba03[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("quarto").click();








function opennomecidade02(nomecidade,elmnt,color) {

  var seila, conteudo04, aba02;
  conteudo04 = document.getElementsByClassName("conteudo04");
  for (seila = 0; seila < conteudo04.length; seila++) {
    conteudo04[seila].style.display = "none";
  }

  aba02 = document.getElementsByClassName("aba02");
  for (seila = 0; seila < aba02.length; seila++) {
    aba02[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("terceiro").click();








function opennomecidade01(nomecidade,elmnt,color) {

  var seila, conteudo03, aba01;
  conteudo03 = document.getElementsByClassName("conteudo03");
  for (seila = 0; seila < conteudo03.length; seila++) {
    conteudo03[seila].style.display = "none";
  }

  aba01 = document.getElementsByClassName("aba01");
  for (seila = 0; seila < aba01.length; seila++) {
    aba01[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("segundo").click();








function opennomecidade(nomecidade,elmnt,color) {

  var seila, conteudo02, aba;
  conteudo02 = document.getElementsByClassName("conteudo02");
  for (seila = 0; seila < conteudo02.length; seila++) {
    conteudo02[seila].style.display = "none";
  }

  aba = document.getElementsByClassName("aba");
  for (seila = 0; seila < aba.length; seila++) {
    aba[seila].style.backgroundColor = "";
  }

  document.getElementById(nomecidade).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("primeiro").click();








function openCity(evt, cityName) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();













function applyFilters(filters, blocks) {
  let count = 0
  let error = document.querySelector('.no-results')

  error.classList.contains('is-active') && error.classList.remove('is-active')

  if (filters["categories"].length === 0 && filters['search'].length === 0){
    blocks.forEach((block) => {
      document.querySelector('#js-content').insertAdjacentHTML('beforeend', block.outerHTML);

      count = 0
    })
  } else {
    document.querySelector('#js-content').innerHTML = ''
    
    let filtered = []
    
    blocks.forEach((block, index) => {
      let contentBlock = block.textContent.toLowerCase()
      var search = contentBlock.indexOf(filters['search']);
      if (search >= 0) {
        let getcategories = block.dataset.categories.split(', ');
        if(filters["categories"].some(r => getcategories.indexOf(r) >= 0)) {
          filtered.push(block)
        }
      }
    })
    
    let perPage = 30
    let pages = Math.ceil(filtered.length / 30)

    for(let i = 0; i <= pages -1; i++) {
      let newPage = document.createElement("div");
      newPage.setAttribute('data-page', i + 1)
      count++
      
      if(i == 0) {
        newPage.classList.add('is-active')
      }
      
      for(let j = 1; j <= perPage; j++) {
        let index = (j - 1) + (i * perPage)
        
        if(filtered[index]) {
          newPage.append(filtered[index])         
        }
      }
      
      document.querySelector('#js-content').appendChild(newPage)
      checkPagination()
    }
    
    if (count === 0) {
      !error.classList.contains('is-active') && error.classList.add('is-active')
      checkPagination()
    }
  }
}
  
function pageNext() {
  const prevButton = document.querySelector('[data-rel="prev"]')
  const nextButton = document.querySelector('[data-rel="next"]')
  nextButton.addEventListener('click', function() {
    const currentPageEl = document.querySelector('[data-page].is-active')
    const currentPage = parseInt(currentPageEl.dataset.page)
    const nextPage = currentPage + 1
    if (document.querySelector('[data-page="'+ nextPage +'"]')) {
      currentPageEl.classList.remove('is-active')
      document.querySelector('[data-page="'+ nextPage +'"]').classList.add('is-active')
    }
    checkPagination()
  })
}

function pagePrev() {
  const prevButton = document.querySelector('[data-rel="prev"]')
  const nextButton = document.querySelector('[data-rel="next"]')
  prevButton.addEventListener('click', function() {
    const currentPageEl = document.querySelector('[data-page].is-active')
    const currentPage = parseInt(currentPageEl.dataset.page)
    const prevPage = currentPage - 1
    if (document.querySelector('[data-page="'+ prevPage +'"]')) {
      currentPageEl.classList.remove('is-active')
      document.querySelector('[data-page="'+ prevPage +'"]').classList.add('is-active')
    }
    checkPagination()
  })
}

function checkPagination() {
  const prevButton = document.querySelector('[data-rel="prev"]')
  const nextButton = document.querySelector('[data-rel="next"]')
  const currentPageEl = document.querySelector('[data-page].is-active')
  let currentPage = 1
  if (currentPageEl) {
    currentPage = parseInt(currentPageEl.dataset.page)
  }
  const prevPage = currentPage - 1
  const nextPage = currentPage + 1
  
  if (document.querySelector('[data-page="'+ (nextPage) +'"]')) {
    nextButton.removeAttribute('disabled')
  } else {
    nextButton.setAttribute('disabled', 'disabled')
  }
  if (document.querySelector('[data-page="'+ (prevPage) +'"]')) {
    prevButton.removeAttribute('disabled')
  } else {
    prevButton.setAttribute('disabled', 'disabled')
  }
}

const pages = document.querySelectorAll('[data-page]')
const blocks = document.querySelectorAll('[data-item]')



let filters = document.querySelector('#js-filters')
let activeFilters = {
  "categories": [],
  "search": [],
}

if (blocks.length > 0 && filters) {
  let tag;
  const tags = document.querySelectorAll('[data-tag]')

  filters.addEventListener('submit', function (e) {
    e.preventDefault()

    tag = filters.querySelector('[data-tag]:checked');
    if (tag) {
      activeFilters[tag.dataset.tag] = []
      activeFilters[tag.dataset.tag].push(tag.value)
    } else {
      tags.forEach((tag) => {
        activeFilters[tag.dataset.tag].push(tag.value)
      })
    }
    
    activeFilters['search'] = []
    if (document.getElementById("keywords").value != "") {
      activeFilters['search'].push(document.getElementById("keywords").value.toLowerCase())
    }
    
    applyFilters(activeFilters, blocks)
  })
}

checkPagination()
pageNext()
pagePrev()






// Get the modal
var modal03 = document.getElementById("myModal03");

// seleciona o iframe
var iframe03 = document.getElementsByClassName('player03')[0];

// Get the button that opens the modal
var btn03 = document.getElementById("myBtn03");

// Get the <span> element that closes the modal
var button03 = document.getElementsByClassName("close03")[0];

// When the user clicks on the button, open the modal
btn03.onclick = function() {
  modal03.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
button03.onclick = function() {
  modal03.style.display = "none";
  iframe03.setAttribute('src', iframe03.getAttribute('src'));
};








// Get the modal
var modal02 = document.getElementById("myModal02");

// seleciona o iframe
var iframe02 = document.getElementsByClassName('player02')[0];

// Get the button that opens the modal
var btn02 = document.getElementById("myBtn02");

// Get the <span> element that closes the modal
var button02 = document.getElementsByClassName("close02")[0];

// When the user clicks on the button, open the modal
btn02.onclick = function() {
  modal02.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
button02.onclick = function() {
  modal02.style.display = "none";
  iframe02.setAttribute('src', iframe02.getAttribute('src'));
};




document.getElementById("concluir03").onclick = function senha03() {
  var senha03 = 'Cal07bon22';
  var senhadig = document.getElementById("senha03").value;

  if (senha03 == senhadig){
    document.getElementById("over03").style.display="none"
  }else if (senha03 != senhadig){
    window.location.href='karaokedigital.html';
  }
}
